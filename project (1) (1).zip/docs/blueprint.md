# **App Name**: RepurposeGenie

## Core Features:

- User Authentication & OTP: Secure sign-up and login with email verification and an interactive OTP entry screen with resend timer.
- Content Input Interface: Input field for YouTube URLs or long text with a 'Generate' button.
- AI Content Generation Tool: Utilize AI to repurpose provided content into 10 distinct social media posts formatted for LinkedIn, Twitter, TikTok, and Instagram.
- Generated Posts Display: Responsive grid display of generated social media posts, each with a 'Copy to Clipboard' button.
- User Profile Management: View user avatar, name, verified email status, subscription plan, total posts generated, and remaining credits.
- Account & Preference Settings: Manage account details (change password, update email with re-verification), set display preferences (dark/light mode), and configure OpenAI API keys.
- Modern Sidebar Navigation: Clean, persistent sidebar for seamless navigation between Dashboard, Profile, and Settings without page reloads.

## Style Guidelines:

- Color Anchor: 'Pastel Lavender' evoking calm and creativity. Light color scheme chosen for a clean, minimalist feel, aligned with off-white request.
- Primary color: A sophisticated lavender (#9C80BC) with good contrast for a light background.
- Background color: A very light, desaturated purple (#FDFCFE) for a soft off-white appearance.
- Accent color: A soft, analogous pink-purple (#BC80AC) for highlighting interactive elements.
- Body and headline font: 'Inter' (sans-serif) for a modern, objective, and clean aesthetic, suitable for highly structured content.
- Minimalist and outline-style icons to complement the modern, clean UI. Focus on clarity and simplicity for navigation and actions.
- Structured and modular layout with ample white space to enhance readability and user focus. Responsive design ensuring usability across various screen sizes.
- Subtle loading animations for the 'Generate' button and smooth transitions for page navigations within the sidebar to provide a fluid user experience.