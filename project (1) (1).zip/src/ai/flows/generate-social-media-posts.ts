
'use server';
/**
 * @fileOverview A Genkit flow for generating social media posts from a given YouTube URL or long text.
 *
 * - generateSocialMediaPosts - A function that orchestrates the generation of social media posts.
 * - GenerateSocialMediaPostsInput - The input type for the generateSocialMediaPosts function.
 * - GenerateSocialMediaPostsOutput - The return type for the generateSocialMediaPosts function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

// Input Schema
const GenerateSocialMediaPostsInputSchema = z.object({
  contentType: z.enum(['youtubeUrl', 'longText']).describe('The type of content provided.'),
  content: z.string().min(1).describe('The YouTube URL or long-form text content.'),
});
export type GenerateSocialMediaPostsInput = z.infer<typeof GenerateSocialMediaPostsInputSchema>;

// Output Schema
const SocialMediaPostSchema = z.object({
  platform: z.enum(['LinkedIn', 'Twitter', 'TikTok', 'Instagram']).describe('The social media platform the post is designed for.'),
  content: z.string().describe('The content of the social media post.'),
  hashtags: z.array(z.string()).optional().describe('Relevant hashtags for the post.'),
});

const GenerateSocialMediaPostsOutputSchema = z.array(SocialMediaPostSchema).length(10).describe('An array of exactly 10 distinct social media posts.');
export type GenerateSocialMediaPostsOutput = z.infer<typeof GenerateSocialMediaPostsOutputSchema>;

export async function generateSocialMediaPosts(
  input: GenerateSocialMediaPostsInput
): Promise<GenerateSocialMediaPostsOutput> {
  return generateSocialMediaPostsFlow(input);
}

const generateSocialMediaPostsPrompt = ai.definePrompt({
  name: 'generateSocialMediaPostsPrompt',
  input: { schema: GenerateSocialMediaPostsInputSchema },
  output: { schema: GenerateSocialMediaPostsOutputSchema },
  prompt: `You are RepurposeGenie, an AI expert at transforming long-form content into high-impact social media posts.

Your task is to generate exactly 10 distinct social media posts based on the provided content.

{{#if (eq contentType "youtubeUrl")}}
INPUT: A YouTube Video URL: {{{content}}}
INSTRUCTION: Based on the context of this video (or common knowledge if the URL is specific), generate engaging posts that would promote or summarize the value of such a video.
{{else}}
INPUT: Long-form Text: {{{content}}}
INSTRUCTION: Analyze this text and extract key insights, quotes, and themes to create engaging social media posts.
{{/if}}

PLATFORMS: LinkedIn, Twitter, TikTok, Instagram.
DISTRIBUTION: Ensure a balanced mix across these platforms.
STYLE: Tailor each post's tone and length to its platform (e.g., professional for LinkedIn, punchy for Twitter).

Generate exactly 10 posts in total.
`,
});

const generateSocialMediaPostsFlow = ai.defineFlow(
  {
    name: 'generateSocialMediaPostsFlow',
    inputSchema: GenerateSocialMediaPostsInputSchema,
    outputSchema: GenerateSocialMediaPostsOutputSchema,
  },
  async (input) => {
    try {
      const { output } = await generateSocialMediaPostsPrompt(input);
      if (!output) {
        throw new Error('AI returned empty output');
      }
      return output;
    } catch (error) {
      console.error('Genkit flow error:', error);
      throw new Error('Failed to generate posts. Please check your AI configuration.');
    }
  }
);
