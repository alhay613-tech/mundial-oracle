
"use client"

export interface User {
  id: string;
  email: string;
  name: string;
  isVerified: boolean;
}

const STORAGE_KEY = 'repurpose_genie_user';

export const authService = {
  getUser: (): User | null => {
    if (typeof window === 'undefined') return null;
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : null;
  },

  signup: (name: string, email: string) => {
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      isVerified: false
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    return newUser;
  },

  verify: () => {
    const user = authService.getUser();
    if (user) {
      user.isVerified = true;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    }
    return user;
  },

  login: (email: string) => {
    // Mock login: if user exists with this email, log them in
    const user = authService.getUser();
    if (user && user.email === email) {
      return user;
    }
    // For demo: create a user if they don't exist
    const newUser: User = {
      id: 'demo-user',
      name: 'Demo User',
      email,
      isVerified: true
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    return newUser;
  },

  logout: () => {
    localStorage.removeItem(STORAGE_KEY);
  },

  isAuthenticated: (): boolean => {
    const user = authService.getUser();
    return !!(user && user.isVerified);
  }
};
