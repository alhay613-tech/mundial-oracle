import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sparkles, ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-6 lg:px-12 h-20 flex items-center border-b bg-background/50 backdrop-blur-md sticky top-0 z-50">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/20">
            <Sparkles className="w-6 h-6" />
          </div>
          <span className="font-headline text-2xl font-bold tracking-tight text-primary">RepurposeGenie</span>
        </Link>
        <nav className="ml-auto flex gap-4">
          <Button variant="ghost" asChild>
            <Link href="/login">Log in</Link>
          </Button>
          <Button className="shadow-md shadow-primary/10" asChild>
            <Link href="/signup">Start Free</Link>
          </Button>
        </nav>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-5xl mx-auto space-y-12">
        <div className="space-y-6">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter text-foreground font-headline leading-tight">
            Turn your long content into <span className="text-primary italic">Viral Posts</span> in seconds.
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Generate high-performing LinkedIn, Twitter, TikTok, and Instagram posts from your YouTube videos or long-form text with AI.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button size="lg" className="h-14 px-8 text-lg rounded-2xl shadow-xl shadow-primary/20" asChild>
            <Link href="/signup">
              Get Started for Free <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-2xl border-primary/20 hover:bg-primary/5">
            View Templates
          </Button>
        </div>

        <div className="relative w-full aspect-video rounded-3xl overflow-hidden border shadow-2xl shadow-primary/10 bg-muted/20">
          <img 
            src="https://picsum.photos/seed/repurpose/1200/800" 
            alt="RepurposeGenie Dashboard Preview" 
            className="w-full h-full object-cover opacity-80"
            data-ai-hint="dashboard preview"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent flex items-end p-8">
            <div className="flex gap-4 items-center">
               <div className="flex -space-x-3">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-background bg-muted">
                      <img src={`https://picsum.photos/seed/user${i}/40/40`} className="rounded-full" />
                    </div>
                  ))}
               </div>
               <p className="text-sm font-medium">Trusted by 2,000+ content creators</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="py-12 px-6 border-t mt-20 text-center">
        <p className="text-muted-foreground">© 2024 RepurposeGenie. All rights reserved.</p>
      </footer>
    </div>
  )
}