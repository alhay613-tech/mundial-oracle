"use client"

import { useState } from "react"
import { 
  Key, 
  User, 
  Mail, 
  Lock, 
  Globe, 
  Moon, 
  Sun,
  ShieldCheck,
  Eye,
  EyeOff
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"

export default function SettingsPage() {
  const [showApiKey, setShowApiKey] = useState(false)
  const { toast } = useToast()

  const handleSave = () => {
    toast({ title: "Settings Saved", description: "Your preferences have been updated successfully." })
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="space-y-2">
        <h1 className="text-4xl font-headline font-bold">Settings</h1>
        <p className="text-muted-foreground text-lg">Manage your account preferences and integrations.</p>
      </div>

      <div className="space-y-8">
        {/* Account Settings */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold font-headline">Account Details</h2>
          </div>
          <Card className="border-none shadow-lg shadow-primary/5">
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="s-email">Email Address</Label>
                  <div className="relative">
                    <Input id="s-email" defaultValue="alex@example.com" className="pr-10" />
                    <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  </div>
                  <p className="text-[10px] text-muted-foreground">Requires OTP verification to change</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="s-password">Change Password</Label>
                  <div className="relative">
                    <Input id="s-password" type="password" placeholder="••••••••" className="pr-10" />
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={handleSave} className="rounded-lg h-9">Update Account</Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* AI Configuration */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold font-headline">API Management</h2>
          </div>
          <Card className="border-none shadow-lg shadow-primary/5 bg-primary/5">
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="api-key" className="text-sm font-semibold">OpenAI API Key</Label>
                  <Badge variant="outline" className="text-[10px] bg-background">Private</Badge>
                </div>
                <div className="relative">
                  <Input 
                    id="api-key" 
                    type={showApiKey ? "text" : "password"} 
                    placeholder="sk-..." 
                    defaultValue="sk-proj-4jK2L9m8N7P6O5I4U3Y2T1R0E9W8Q7Z6X5C4V3B2N1M0..."
                    className="pr-10 font-mono text-xs h-11 bg-background" 
                  />
                  <button 
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors"
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Your API key is encrypted and stored locally. We never see your secret keys.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Preferences */}
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold font-headline">Preferences</h2>
          </div>
          <Card className="border-none shadow-lg shadow-primary/5">
            <CardContent className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-semibold">Appearance</Label>
                  <p className="text-sm text-muted-foreground">Switch between light and dark themes.</p>
                </div>
                <div className="flex items-center gap-2 bg-muted p-1 rounded-lg">
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-md"><Sun className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-md"><Moon className="w-4 h-4" /></Button>
                </div>
              </div>
              
              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-semibold">Default Language</Label>
                  <p className="text-sm text-muted-foreground">Select the default output language for your posts.</p>
                </div>
                <Select defaultValue="en">
                  <SelectTrigger className="w-40 h-10 rounded-lg">
                    <SelectValue placeholder="Select Language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English (US)</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="de">German</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-semibold">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive weekly content performance reports.</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </section>
        
        <div className="flex justify-end pt-4 pb-12">
          <Button size="lg" className="px-12 h-12 rounded-xl shadow-xl shadow-primary/20" onClick={handleSave}>
            Save All Changes
          </Button>
        </div>
      </div>
    </div>
  )
}