"use client"

import { 
  UserCircle, 
  CreditCard, 
  TrendingUp, 
  CheckCircle2, 
  Award,
  Zap
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function ProfilePage() {
  const stats = [
    { label: "Total Posts Generated", value: "1,248", icon: TrendingUp, color: "text-blue-500" },
    { label: "Content Sources", value: "42", icon: UserCircle, color: "text-purple-500" },
    { label: "Engagement Lift", value: "3.4x", icon: Award, color: "text-orange-500" },
  ]

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <Card className="w-full md:w-80 shadow-xl shadow-primary/5 border-none bg-gradient-to-b from-card to-primary/5">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-4">
              <Avatar className="w-24 h-24 border-4 border-background shadow-lg">
                <AvatarImage src="https://picsum.photos/seed/user123/200/200" />
                <AvatarFallback>AR</AvatarFallback>
              </Avatar>
            </div>
            <CardTitle className="text-2xl font-headline">Alex Rivers</CardTitle>
            <CardDescription className="flex items-center justify-center gap-1.5 mt-1">
              alex@example.com
              <CheckCircle2 className="w-4 h-4 text-primary fill-primary/10" />
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-background/50 border">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary fill-primary" />
                <span className="text-sm font-semibold">Premium Plan</span>
              </div>
              <Badge className="bg-primary/20 text-primary border-none text-[10px] uppercase font-bold">Active</Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground font-medium">Credits Used</span>
                <span className="font-semibold text-primary">750 / 1000</span>
              </div>
              <Progress value={75} className="h-2 bg-muted border-none" />
              <p className="text-[10px] text-muted-foreground text-center">Resets in 12 days</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex-1 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat, i) => (
              <Card key={i} className="border-none shadow-md shadow-primary/5">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className={`p-2 rounded-lg bg-muted`}>
                      <stat.icon className={`w-5 h-5 ${stat.color}`} />
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold font-headline">{stat.value}</h3>
                  <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-none shadow-md shadow-primary/5 overflow-hidden">
            <CardHeader className="border-b bg-muted/5">
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {[
                  { title: "YouTube Video: Modern Web Design", date: "2 hours ago", type: "Generated 10 posts" },
                  { title: "Blog Post: Why AI is the Future", date: "Yesterday", type: "Generated 10 posts" },
                  { title: "Transcript: Podcasting 101", date: "3 days ago", type: "Generated 10 posts" },
                  { title: "Notes: SEO Checklist", date: "1 week ago", type: "Generated 10 posts" },
                ].map((item, i) => (
                  <div key={i} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                    <div className="space-y-1">
                      <p className="font-medium">{item.title}</p>
                      <p className="text-xs text-muted-foreground">{item.type}</p>
                    </div>
                    <span className="text-xs font-medium text-muted-foreground">{item.date}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}