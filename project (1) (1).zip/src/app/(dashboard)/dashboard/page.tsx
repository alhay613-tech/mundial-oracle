
"use client"

import { useState } from "react"
import { Sparkles, Youtube, AlignLeft, Send, Loader2, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { PostCard } from "@/components/dashboard/post-card"
import { useToast } from "@/hooks/use-toast"

type Platform = 'LinkedIn' | 'Twitter' | 'TikTok' | 'Instagram'

interface MockPost {
  platform: Platform
  content: string
  hashtags: string[]
}

const MOCK_POSTS: MockPost[] = [
  {
    platform: "LinkedIn",
    content: "I've spent the last week diving deep into how generative AI is fundamentally shifting the creator economy. 🚀\n\nThe biggest takeaway? It's no longer about 'creating more content'—it's about 'amplifying the right content.' \n\nWe're moving from a linear production model to a hub-and-spoke strategy. One high-quality video can now fuel an entire month's worth of multi-platform engagement if you have the right tools.\n\nWhat are you doing to maximize your content ROI this year?",
    hashtags: ["#ContentStrategy", "#AI", "#CreatorEconomy", "#Marketing"]
  },
  {
    platform: "Twitter",
    content: "Stop sleeping on content repurposing. 😴\n\n1 Great YouTube Video =\n- 3 LinkedIn Deep Dives\n- 5 Viral Tweets\n- 2 Instagram Reels\n- 1 Long-form Article\n\nEfficiency > Effort. 🧵",
    hashtags: ["#Solopreneur", "#MarketingTips"]
  },
  {
    platform: "Instagram",
    content: "The future of content is modular. ✨ \n\nSwipe to see how we turned one 10-minute workshop into 10 high-impact social posts in less than 60 seconds. \n\nNo more staring at a blank screen. Just pure, AI-assisted productivity. 🔥",
    hashtags: ["#SocialMediaManager", "#WorkSmarter", "#DesignInspo"]
  },
  {
    platform: "LinkedIn",
    content: "Productivity hack for 2024: Don't start from zero.\n\nMost people fail at content because they treat every post as a new project. \n\nThe professionals treat their core ideas as assets. They invest in one 'pillar' piece and then let the AI slice it into bite-sized insights.\n\nThis isn't just about saving time; it's about consistency. Consistency is what builds authority.",
    hashtags: ["#PersonalBranding", "#Productivity", "#Leadership"]
  },
  {
    platform: "Twitter",
    content: "Most 'AI' tools just generate generic noise. 📉\n\nThe real power is using AI to translate your *existing* voice across different formats. \n\nKeep the soul, automate the formatting. That's the winning play. ⚡️",
    hashtags: ["#TechTrends", "#AItools"]
  },
  {
    platform: "TikTok",
    content: "POV: You just found the ultimate cheat code for content creators. 🤫 \n\nI used to spend 5 hours editing posts. Now? I just paste a link and let the genie do the work. \n\nWatch till the end for the results. 📈",
    hashtags: ["#LifeHack", "#CreatorTips", "#RepurposeGenie"]
  },
  {
    platform: "Instagram",
    content: "Workflow check! 📱 \n\nInput: YouTube URL 🔗\nOutput: 10 Ready-to-post drafts ✍️\n\nEnergy: Saved ✅\nSanity: Intact ✅\nGrowth: Pending... 🚀",
    hashtags: ["#DigitalMarketing", "#GrowthHacking"]
  },
  {
    platform: "TikTok",
    content: "Wait, you're still writing your tweets manually? 💀\n\nCheck out how I scale my personal brand while I'm literally at the gym. \n\nLink in bio to try it yourself! 👇",
    hashtags: ["#AIRevolution", "#PassiveIncome", "#SideHustle"]
  },
  {
    platform: "LinkedIn",
    content: "Data shows that users who repurpose their content see a 340% increase in total reach compared to those who post one-off pieces.\n\nWhy? Because your audience isn't on every platform at once. \n\nMeet them where they are. In the format they prefer. With the insights you've already validated.",
    hashtags: ["#DataDriven", "#MarketingStrategy", "#B2B"]
  },
  {
    platform: "Twitter",
    content: "Quality is subjective. Quantity is a numbers game. \n\nRepurposing allows you to play both at the same time. \n\nGame. Set. Match. 🎾",
    hashtags: ["#Entrepreneurship", "#BuildInPublic"]
  }
]

export default function DashboardPage() {
  const [loading, setLoading] = useState(false)
  const [content, setContent] = useState("")
  const [contentType, setContentType] = useState<"youtubeUrl" | "longText">("youtubeUrl")
  const [posts, setPosts] = useState<MockPost[]>([])
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!content.trim()) {
      toast({ title: "Content required", description: "Please enter a URL or some text.", variant: "destructive" })
      return
    }

    setLoading(true)
    setPosts([])
    
    // Simulate high-fidelity AI processing delay
    setTimeout(() => {
      setPosts(MOCK_POSTS)
      setLoading(false)
      toast({ 
        title: "Magic Complete!", 
        description: "We've repurposed your content into 10 optimized drafts." 
      })
    }, 2000)
  }

  return (
    <div className="space-y-10">
      <div className="space-y-2">
        <h1 className="text-4xl font-headline font-bold">Content Toolkit</h1>
        <p className="text-muted-foreground text-lg">Repurpose your long-form assets into bite-sized social gems.</p>
      </div>

      <Card className="border-none shadow-xl shadow-primary/5 bg-gradient-to-br from-card to-secondary/30">
        <CardContent className="p-8 space-y-6">
          <Tabs defaultValue="youtubeUrl" className="w-full" onValueChange={(val) => setContentType(val as any)}>
            <div className="flex items-center justify-between mb-4">
              <TabsList className="bg-background/80 border p-1 rounded-xl h-12">
                <TabsTrigger value="youtubeUrl" className="gap-2 rounded-lg px-6 data-[state=active]:shadow-sm">
                  <Youtube className="w-4 h-4" /> YouTube Video
                </TabsTrigger>
                <TabsTrigger value="longText" className="gap-2 rounded-lg px-6 data-[state=active]:shadow-sm">
                  <AlignLeft className="w-4 h-4" /> Long-form Text
                </TabsTrigger>
              </TabsList>
              
              <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground bg-background/50 px-3 py-1.5 rounded-full border">
                <AlertCircle className="w-3 h-3" />
                <span>Supports transcripts up to 10k words</span>
              </div>
            </div>
            
            <TabsContent value="youtubeUrl" className="mt-0 focus-visible:ring-0">
              <Textarea 
                placeholder="Paste your YouTube video URL here... (e.g., https://youtube.com/watch?v=...)"
                className="min-h-[120px] text-lg p-4 rounded-2xl resize-none focus-visible:ring-primary/20 border-primary/10 shadow-inner"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </TabsContent>
            
            <TabsContent value="longText" className="mt-0 focus-visible:ring-0">
              <Textarea 
                placeholder="Paste your article, blog post, or raw notes here..."
                className="min-h-[120px] text-lg p-4 rounded-2xl resize-none focus-visible:ring-primary/20 border-primary/10 shadow-inner"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </TabsContent>
          </Tabs>

          <div className="flex justify-end">
            <Button 
              size="lg" 
              className="h-14 px-10 rounded-2xl gap-2 shadow-lg shadow-primary/20 text-lg font-semibold"
              onClick={handleGenerate}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating Magic...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Repurpose Now
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {posts.length > 0 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-headline font-semibold">Your Social Drafts</h2>
            <p className="text-sm text-muted-foreground">{posts.length} posts generated</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {posts.map((post, i) => (
              <PostCard 
                key={i}
                platform={post.platform}
                content={post.content}
                hashtags={post.hashtags}
              />
            ))}
          </div>
        </div>
      )}

      {loading && posts.length === 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {[1,2,3,4,5,6,7,8,9,10].map(i => (
            <div key={i} className="h-64 rounded-2xl border-2 border-dashed border-primary/10 bg-primary/5 animate-pulse" />
          ))}
        </div>
      )}
    </div>
  )
}
