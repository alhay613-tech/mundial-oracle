
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ShieldCheck, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { OTPInput } from "@/components/auth/otp-input"
import { useToast } from "@/hooks/use-toast"
import { authService } from "@/lib/auth-service"

export default function VerifyPage() {
  const [loading, setLoading] = useState(false)
  const [resendTimer, setResendTimer] = useState(30)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => prev - 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [resendTimer])

  const handleVerify = (otp: string) => {
    setLoading(true)
    // Mock verification
    setTimeout(() => {
      authService.verify()
      setLoading(false)
      toast({ title: "Account Verified!", description: "Welcome to RepurposeGenie." })
      router.push("/dashboard")
    }, 1500)
  }

  const handleResend = () => {
    if (resendTimer === 0) {
      setResendTimer(30)
      toast({ title: "New code sent", description: "Check your email for the OTP." })
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <Card className="w-full max-w-md shadow-2xl border-primary/10 shadow-primary/5">
        <CardHeader className="space-y-4 text-center">
          <div className="flex justify-center">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
              <ShieldCheck className="w-7 h-7" />
            </div>
          </div>
          <div>
            <CardTitle className="text-3xl font-headline font-bold">Verify Email</CardTitle>
            <CardDescription className="text-base">
              We've sent a 6-digit verification code to your email address.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <OTPInput length={6} onComplete={handleVerify} />
          
          <div className="text-center">
            <button 
              onClick={handleResend}
              disabled={resendTimer > 0}
              className={`text-sm font-medium ${resendTimer > 0 ? "text-muted-foreground cursor-not-allowed" : "text-primary hover:underline"}`}
            >
              {resendTimer > 0 ? `Resend code in ${resendTimer}s` : "Resend OTP"}
            </button>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            className="w-full h-11 text-base rounded-xl" 
            onClick={() => handleVerify("123456")}
            disabled={loading}
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Verify Now"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
