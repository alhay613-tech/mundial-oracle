"use client"

import * as React from "react"
import { Input } from "@/components/ui/input"

interface OTPInputProps {
  length?: number
  onComplete: (otp: string) => void
}

export function OTPInput({ length = 6, onComplete }: OTPInputProps) {
  const [otp, setOtp] = React.useState<string[]>(new Array(length).fill(""))
  const inputRefs = React.useRef<(HTMLInputElement | null)[]>([])

  const handleChange = (element: HTMLInputElement, index: number) => {
    if (isNaN(Number(element.value))) return

    const newOtp = [...otp]
    newOtp[index] = element.value
    setOtp(newOtp)

    if (element.value !== "" && index < length - 1) {
      inputRefs.current[index + 1]?.focus()
    }

    if (newOtp.every((val) => val !== "")) {
      onComplete(newOtp.join(""))
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === "Backspace") {
      if (otp[index] === "" && index > 0) {
        inputRefs.current[index - 1]?.focus()
      }
    }
  }

  const handlePaste = (e: React.ClipboardEvent) => {
    const pasteData = e.clipboardData.getData("text").slice(0, length)
    if (!/^\d+$/.test(pasteData)) return

    const newOtp = pasteData.split("")
    const updatedOtp = [...otp]
    newOtp.forEach((char, i) => {
      updatedOtp[i] = char
    })
    setOtp(updatedOtp)
    
    const lastIndex = Math.min(newOtp.length - 1, length - 1)
    inputRefs.current[lastIndex]?.focus()

    if (updatedOtp.every(v => v !== "")) {
      onComplete(updatedOtp.join(""))
    }
  }

  return (
    <div className="flex gap-2 justify-center">
      {otp.map((data, index) => (
        <Input
          key={index}
          type="text"
          maxLength={1}
          value={data}
          ref={(el) => { inputRefs.current[index] = el }}
          onChange={(e) => handleChange(e.target, index)}
          onKeyDown={(e) => handleKeyDown(e, index)}
          onPaste={handlePaste}
          className="w-10 h-12 text-center text-lg font-semibold focus:ring-primary border-primary/20"
        />
      ))}
    </div>
  )
}