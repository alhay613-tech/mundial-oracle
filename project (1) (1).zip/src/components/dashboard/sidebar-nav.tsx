
"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { 
  LayoutDashboard, 
  UserCircle, 
  Settings, 
  Sparkles, 
  LogOut,
  ChevronLeft,
  ChevronRight
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { authService } from "@/lib/auth-service"

const navItems = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "My Profile", href: "/profile", icon: UserCircle },
  { name: "Settings", href: "/settings", icon: Settings },
]

export function SidebarNav() {
  const pathname = usePathname()
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)

  const handleLogout = () => {
    authService.logout()
    router.push("/login")
  }

  return (
    <div 
      className={cn(
        "flex flex-col h-screen border-r bg-sidebar-background transition-all duration-300",
        collapsed ? "w-20" : "w-64"
      )}
    >
      <div className="p-6 flex items-center gap-3 h-20 border-b overflow-hidden whitespace-nowrap">
        <div className="w-10 h-10 min-w-10 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/20">
          <Sparkles className="w-6 h-6" />
        </div>
        {!collapsed && (
          <span className="font-headline text-xl font-bold tracking-tight text-primary">RepurposeGenie</span>
        )}
      </div>

      <nav className="flex-1 p-4 space-y-2 mt-4">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "group flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 overflow-hidden whitespace-nowrap",
                  isActive 
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold shadow-sm" 
                    : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                )}
              >
                <item.icon className={cn("w-5 h-5 min-w-5", isActive ? "text-primary" : "text-muted-foreground group-hover:text-primary")} />
                {!collapsed && <span>{item.name}</span>}
              </div>
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t space-y-2">
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-3 w-full px-3 py-3 rounded-xl text-sidebar-foreground hover:bg-sidebar-accent/50 transition-all overflow-hidden whitespace-nowrap"
        >
          {collapsed ? <ChevronRight className="w-5 h-5 min-w-5" /> : <ChevronLeft className="w-5 h-5 min-w-5" />}
          {!collapsed && <span className="text-sm font-medium">Collapse Sidebar</span>}
        </button>
        <button 
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-destructive hover:bg-destructive/5 transition-all overflow-hidden whitespace-nowrap text-left"
        >
          <LogOut className="w-5 h-5 min-w-5" />
          {!collapsed && <span className="text-sm font-medium">Log Out</span>}
        </button>
      </div>
    </div>
  )
}
