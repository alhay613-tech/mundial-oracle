"use client"

import { useState } from "react"
import { 
  Copy, 
  Check, 
  Linkedin, 
  Twitter, 
  Instagram, 
  Music2, 
  MoreVertical 
} from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

interface PostCardProps {
  platform: 'LinkedIn' | 'Twitter' | 'TikTok' | 'Instagram'
  content: string
  hashtags?: string[]
}

const platformIcons = {
  LinkedIn: <Linkedin className="w-4 h-4 text-blue-700" />,
  Twitter: <Twitter className="w-4 h-4 text-sky-500" />,
  Instagram: <Instagram className="w-4 h-4 text-pink-600" />,
  TikTok: <Music2 className="w-4 h-4 text-foreground" />,
}

export function PostCard({ platform, content, hashtags }: PostCardProps) {
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const copyToClipboard = () => {
    const fullText = `${content}\n\n${hashtags?.join(" ")}`
    navigator.clipboard.writeText(fullText)
    setCopied(true)
    toast({ title: "Copied!", description: "Post content copied to clipboard." })
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="h-full flex flex-col hover:shadow-lg transition-all border-primary/5 shadow-sm">
      <CardHeader className="p-4 flex flex-row items-center justify-between space-y-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
            {platformIcons[platform]}
          </div>
          <span className="font-semibold text-sm">{platform}</span>
        </div>
        <Badge variant="secondary" className="font-normal bg-primary/10 text-primary border-none">
          Ready
        </Badge>
      </CardHeader>
      <CardContent className="p-4 pt-0 flex-1 overflow-hidden">
        <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-6 leading-relaxed">
          {content}
        </p>
        {hashtags && hashtags.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1">
            {hashtags.map((tag) => (
              <span key={tag} className="text-xs text-primary font-medium">{tag}</span>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 pt-0 border-t bg-muted/5">
        <Button 
          variant="ghost" 
          className="w-full justify-start gap-2 h-9 text-xs" 
          onClick={copyToClipboard}
        >
          {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          {copied ? "Copied" : "Copy to Clipboard"}
        </Button>
      </CardFooter>
    </Card>
  )
}